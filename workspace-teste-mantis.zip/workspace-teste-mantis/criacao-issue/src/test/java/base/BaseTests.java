package base;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.HomePage;

public class BaseTests {
	
	private static WebDriver driver;
	protected HomePage homePage;
	
	
	@BeforeAll
	public static void inicializar() {
		System.setProperty("webdriver.chrome.driver", "C:\\webdrivers\\chromedriver\\83\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@BeforeEach
	public void criarIssue() {
		driver.get("https://mantis-prova.base2.com.br/login_page.php");
		homePage = new HomePage(driver);
		
		driver.findElement(By.name("username"));
		WebElement username=driver.findElement(By.name("username"));
		username.sendKeys("jamaira.dias"); 
		
		driver.findElement(By.name("password"));
		WebElement password=driver.findElement(By.name("password"));
		password.sendKeys("123login"); 
		
		driver.findElement(By.xpath("Login"));
		WebElement login=driver.findElement(By.xpath("Login"));
		login.click();
		
		driver.findElement(By.xpath("Report Issue"));
		WebElement criarIssue=driver.findElement(By.xpath("Report Issue"));
		criarIssue.click();
		
		driver.findElement(By.name("project_id"));
		WebElement project_id=driver.findElement(By.name("project_id"));
		project_id.click(); 
		driver.findElement(By.xpath("Jamaira Dias�s Project"));
		WebElement chooseProject=driver.findElement(By.xpath("Jamaira Dias�s Project"));
		chooseProject.click();
		
		driver.findElement(By.xpath("Select Project"));
		WebElement selectProject=driver.findElement(By.xpath("Select Project"));
		selectProject.click();
		
		driver.findElement(By.name("category_id"));
		WebElement category_id=driver.findElement(By.name("category_id"));
		category_id.click();
		driver.findElement(By.xpath("[All Projects] General"));
		WebElement chooseCategory=driver.findElement(By.xpath("[All Projects] General"));
		chooseCategory.click();
		
		driver.findElement(By.name("reproducibility"));
		WebElement reproducibility=driver.findElement(By.name("reproducibility"));
		reproducibility.click();
		driver.findElement(By.xpath("always"));
		WebElement reproducibility_id=driver.findElement(By.xpath("always"));
		reproducibility_id.click();
		
		driver.findElement(By.name("severity"));
		WebElement severity=driver.findElement(By.name("severity"));
		severity.click();
		driver.findElement(By.xpath("minor"));
		WebElement severity_id=driver.findElement(By.xpath("minor"));
		severity_id.click();
		
		driver.findElement(By.name("priority"));
		WebElement priority=driver.findElement(By.name("priority"));
		priority.click();
		driver.findElement(By.xpath("normal"));
		WebElement priority_id=driver.findElement(By.xpath("normal"));
		priority_id.click();
		
		driver.findElement(By.name("profile_id"));
		WebElement profile_id=driver.findElement(By.name("profile_id"));
		profile_id.click();
		driver.findElement(By.xpath("Desktop  Windows 10"));
		WebElement sistema=driver.findElement(By.xpath("Desktop  Windows 10"));
		sistema.click();
		
		driver.findElement(By.name("platform"));
		WebElement platform=driver.findElement(By.name("platform"));
		platform.sendKeys("Unix"); 
		
		driver.findElement(By.name("os"));
		WebElement os=driver.findElement(By.name("os"));
		os.sendKeys("Windows"); 
		
		driver.findElement(By.name("os_build"));
		WebElement os_build=driver.findElement(By.name("os_build"));
		os_build.sendKeys("10 Pro"); 
		
		driver.findElement(By.name("summary"));
		WebElement summary=driver.findElement(By.name("summary"));
		summary.sendKeys("Teste Bug Reportado Jamaira"); 
		
		driver.findElement(By.name("description"));
		WebElement description=driver.findElement(By.name("description"));
		description.sendKeys("Erro ao efetuar login na p�gina");
		
		driver.findElement(By.name("steps_to_reproduce"));
		WebElement steps_to_reproduce=driver.findElement(By.name("steps_to_reproduce"));
		steps_to_reproduce.sendKeys("1. Primeiro passo, 2. Segundo passo, 3. Terceiro passo");
		
		driver.findElement(By.name("additional_info"));
		WebElement additional_info=driver.findElement(By.name("additional_info"));
		additional_info.sendKeys("Bot�o login sem mouse over");
		
		driver.findElement(By.xpath("Submit Report"));
		WebElement submit=driver.findElement(By.xpath("Submit Report"));
		submit.click();
		
		driver.findElement(By.xpath("Logout"));
		WebElement logout=driver.findElement(By.xpath("Logout"));
		logout.click();
		
		driver.findElement(By.name("username"));
		WebElement username1=driver.findElement(By.name("username"));
		username1.sendKeys("jamaira.dias"); 
		
		driver.findElement(By.name("password"));
		WebElement password1=driver.findElement(By.name("password"));
		password1.sendKeys("123login"); 
		
		driver.findElement(By.xpath("Login"));
		WebElement login1=driver.findElement(By.xpath("Login"));
		login1.click();
			
		
	}
	
	@AfterAll
	public static void finalizar() {
		driver.quit();
	}
}
