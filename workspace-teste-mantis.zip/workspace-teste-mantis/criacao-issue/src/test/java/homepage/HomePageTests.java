package homepage;


import org.junit.Test;

import base.BaseTests;

public class HomePageTests extends BaseTests {
	
	@Test
	public void testCriarIssue_IssueNova() {
		criarIssue();
		
		int issuesCriadas = homePage.contarIssue();
		System.out.println(issuesCriadas);
	}
	
	
	

}
